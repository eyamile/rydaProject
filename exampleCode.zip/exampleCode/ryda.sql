-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2018 at 10:39 AM
-- Server version: 5.7.14
-- PHP Version: 7.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ryda`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `addOptions` (IN `o_id` INT(5), IN `q_id` INT(4))  BEGIN
    INSERT INTO `question_option`(`question_id`, `option_id`, `time_added`)
    VALUES (q_id, o_id, NOW());
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `banStudent` (IN `s_id` INT(3))  BEGIN
   
    UPDATE `user`
    SET  `visible` = 0
        WHERE `id` = s_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `createCategory` (IN `cat_name` VARCHAR(50), IN `cat_img` VARCHAR(255))  BEGIN
	
    INSERT INTO `category` (`name`, `image`, `status_id`)
    VALUES(cat_name, cat_img, 1);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `createOption` (IN `o_name` VARCHAR(150), IN `o_score` INT(4), IN `o_feedback` VARCHAR(100), IN `question_id` INT(4))  BEGIN
	
    INSERT INTO `option` (`name`, `score`, `feedback`,  `status_id`)
    VALUES(o_name, o_score, o_feedback, 1);
    
    INSERT INTO `question_option`(`question_id`, `option_id`, `time_added`)
    VALUES (question_id,LAST_INSERT_ID(), NOW());

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `createQuestion` (IN `q_name` VARCHAR(200), IN `q_img` VARCHAR(255), IN `topic_id` INT(3))  BEGIN
	
    INSERT INTO `question` (`name`, `image`, `status_id`,  `topic_id`)
    VALUES(q_name, q_img, 1, topic_id);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `createStudent` (IN `sName` VARCHAR(15), IN `middleName` VARCHAR(15), IN `sSurname` VARCHAR(30), IN `sEmail` VARCHAR(100), IN `mobileNumber` VARCHAR(15), IN `address` VARCHAR(150), IN `birthday` VARCHAR(10), IN `psw` VARCHAR(255), IN `school` INT(5))  BEGIN
	
    INSERT INTO `user` (`role_id`, `name`, `middle_name`, `surname`, `email`, `mobile_number`, `address`, `birthday`, `visible`, `password`, `school_id`)
    VALUES(2, sName, middleName, sSurname, sEmail, mobileNumber, address, birthday, 1, psw, school);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `createTopic` (IN `t_name` VARCHAR(30), IN `t_title` VARCHAR(50), IN `t_img` VARCHAR(255), IN `t_text` TEXT, IN `cat_id` INT(3))  BEGIN
	
    INSERT INTO `topic` (`name`, `content_title`, `content_image`, `content_text`, `category_id`, `status_id`)
    VALUES(t_name, t_title, t_img, t_text, cat_id, 1);

END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delCategory` (IN `cat_id` INT(3))  BEGIN
	UPDATE `category`
    SET `status_id` = 3
    WHERE `id` = cat_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delOption` (IN `o_id` INT(4), IN `q_id` INT(3))  BEGIN
	DELETE FROM `question_option` 
    WHERE `question_id` = q_id
		AND `option_id` = o_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delQuestion` (IN `q_id` INT(3))  BEGIN
	UPDATE `question`
    SET `status_id` = 3
    WHERE `id` = q_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `delTopic` (IN `topic_id` INT(3))  BEGIN
	UPDATE `topic`
    SET `status_id` = 3
    WHERE `id` = topic_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getCategories` ()  BEGIN
	SELECT `id`, `name`, `image`
		FROM `category`
        WHERE `status_id` = 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getCategory` (IN `cat_id` INT(3))  BEGIN
	SELECT `name`
    FROM `category`
    WHERE `id` = cat_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getCat_id` (IN `t_id` INT(3))  BEGIN
	SELECT `category_id` 
	FROM `topic` 
	WHERE `id` = t_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getDetailedOptions` (IN `q_id` INT(3))  BEGIN   
    
 SELECT o.`id`, o.`name`, o.`score`, o.`feedback`
  FROM `option` AS o, `question_option` AS qo
  WHERE qo.`option_id` = o.`id`
	   AND qo.`question_id` = q_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOption` (IN `opt_id` INT(5))  BEGIN
	SELECT `name`, `score`, `feedback`
    FROM `option`
    WHERE `id` = opt_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOptions` (IN `q_id` INT(3))  BEGIN   
    
   SELECT o.`id`, o.`name`
   FROM `option` AS o
   WHERE o.`id` NOT IN
	(SELECT o.`id`
		FROM `option` AS o, `question_option` AS qo
        WHERE qo.`option_id` = o.`id`
              AND qo.`question_id` = q_id);
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getOptionsByQuestion` (IN `q_id` INT(3))  BEGIN
	SELECT o.`id`, o.`name`
		FROM `option` AS o, `question_option` AS qo
        WHERE qo.`option_id` = o.`id`
              AND qo.`question_id` = q_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getPassword` (IN `usrId` INT(11))  BEGIN
			SELECT password
			FROM user
			WHERE id = usrId LIMIT 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getProfile` (IN `u_email` VARCHAR(100))  BEGIN
	SELECT `name`, `middle_name`, `surname`, `mobile_number`, `address`, `birthday`
		FROM `user`
        WHERE `email` = u_email;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getQuestion` (IN `q_id` INT(3))  BEGIN
	SELECT `name`, `image`
    FROM `question`
    WHERE `id` = q_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getQuestions` (IN `t_id` INT(3))  BEGIN


	SELECT `id`, `name`
		FROM `question`
        WHERE `topic_id` = t_id
			AND `status_id` = 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getSchools` ()  BEGIN
	SELECT `id`, `name`
		FROM school;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getScore` (IN `u_mail` VARCHAR(100))  BEGIN
	SELECT `total_score`
    FROM `user`
    WHERE `email` = u_mail;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getStudents` ()  BEGIN

	SELECT `id`, `name`, `surname`, `visible`
		FROM `user` 
        WHERE `role_id` = 2;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTopic` (IN `topic_id` INT(3))  BEGIN
	SELECT `name`, `content_title`, `content_image`, `content_text`
    FROM `topic`
    WHERE `id` = topic_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTopics` (IN `cat_id` INT(3))  BEGIN
	SELECT `id`, `name`, `status_id`
		FROM `topic`
        WHERE `category_id` = cat_id
			AND `status_id` = 1;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `getTopic_id` (IN `q_id` INT(3))  BEGIN
	SELECT `topic_id` 
	FROM `question` 
	WHERE `id` = q_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateCategory` (IN `cat_id` INT(3), IN `cat_name` VARCHAR(50))  BEGIN
   
    UPDATE `category`
    SET  `name` = cat_name
        WHERE `id` = cat_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateOption` (IN `o_id` INT(5), IN `o_name` VARCHAR(150), IN `o_score` INT(4), IN `o_feedback` VARCHAR(100))  BEGIN
   
    UPDATE `option`
    SET  `name` = o_name, 
          `score` = o_score,
          `feedback` = o_feedback
        WHERE `id` = o_id;
        
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateProfile` (IN `u_email` VARCHAR(100), IN `u_name` VARCHAR(15), IN `u_middleName` VARCHAR(15), IN `u_surname` VARCHAR(30), IN `u_phone` VARCHAR(15), IN `u_address` VARCHAR(150))  BEGIN
   
   DECLARE user_id INT;
   SET user_id = getId(u_email);
   
   
    UPDATE `user`
    SET  `name` = u_name, 
		`middle_name`= u_middleName, 
		`surname` = u_surname,
        `mobile_number` = u_phone,
        `address` = u_address
        WHERE `id` = user_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateQuestion` (IN `q_id` INT(3), IN `q_name` VARCHAR(30), IN `q_image` VARCHAR(255))  BEGIN
   
    UPDATE `question`
    SET     `name` = q_name,
			`image` = q_image
	WHERE `id` = q_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateScore` (IN `u_email` VARCHAR(100), IN `u_score` INT(5))  BEGIN
   
   DECLARE user_id INT;
   DECLARE last_score INT;
   DECLARE new_score INT;
   
   SELECT `total_score` INTO last_score
   FROM `user`
   WHERE `email` = u_email;
   
   SET user_id = getId(u_email);
   
   SET new_score = last_score + u_score;
   
   
    UPDATE `user`
    SET  `total_score` = new_score
		    WHERE `id` = user_id;
END$$

CREATE DEFINER=`root`@`localhost` PROCEDURE `updateTopic` (IN `t_id` INT(3), IN `t_name` VARCHAR(30), IN `t_title` VARCHAR(50), IN `t_image` VARCHAR(255), IN `t_text` TEXT)  BEGIN
   
    UPDATE `topic`
    SET     `name` = t_name,
			`content_title` = t_title, 
			`content_image` = t_image,
			`content_text` =t_text
	WHERE `id` = t_id;
END$$

--
-- Functions
--
CREATE DEFINER=`root`@`localhost` FUNCTION `getId` (`u_email` VARCHAR(100)) RETURNS INT(5) BEGIN
DECLARE u_id INT(5);
   
   SELECT `id` INTO u_id FROM `user` WHERE `email`=u_email;


RETURN u_id;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id` int(3) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status_id` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `name`, `image`, `status_id`) VALUES
(18, 'Awareness of the environment', '', 3),
(19, 'test category', '', 3),
(22, 'Environmental awareness', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `login_attempt`
--

CREATE TABLE `login_attempt` (
  `user_id` int(11) NOT NULL,
  `time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `option`
--

CREATE TABLE `option` (
  `id` int(5) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `score` int(4) DEFAULT NULL,
  `feedback` varchar(100) DEFAULT NULL,
  `status_id` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `option`
--

INSERT INTO `option` (`id`, `name`, `score`, `feedback`, `status_id`) VALUES
(1, 'Pedestrians', 10, 'Good', 1),
(2, 'Cyclists', 2, 'not bad', 1),
(3, 'Trucks', 0, 'try again', 1),
(4, 'Motorbikes', 8, 'good', 1),
(5, 'Birds', 0, 'really? ', 1),
(6, 'Mobile phones', 8, 'Definately', 1),
(7, 'Backseat drivers', 10, 'Don\'t we know it', 1),
(8, 'Yes, drugs are bad', 8, 'nice', 1),
(9, 'depends who you ask', 1, 'ok then', 1),
(10, 'Nah, get high while driving every day mate', 0, '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `question`
--

CREATE TABLE `question` (
  `id` int(4) NOT NULL,
  `name` varchar(200) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `status_id` int(2) DEFAULT NULL,
  `topic_id` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question`
--

INSERT INTO `question` (`id`, `name`, `image`, `status_id`, `topic_id`) VALUES
(1, 'Who are some vulnerable road users?', '', 1, 1),
(2, 'What is a major distraction to drivers?', '', 1, 1),
(3, 'Are drugs bad for drivers?', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `question_option`
--

CREATE TABLE `question_option` (
  `question_id` int(11) NOT NULL,
  `option_id` int(11) NOT NULL,
  `time_added` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `question_option`
--

INSERT INTO `question_option` (`question_id`, `option_id`, `time_added`) VALUES
(1, 1, '2018-05-24 19:32:45'),
(1, 2, '2018-05-24 19:33:11'),
(1, 3, '2018-05-24 19:33:23'),
(1, 4, '2018-05-24 19:33:45'),
(1, 5, '2018-05-24 19:34:01'),
(2, 1, '2018-05-24 19:36:09'),
(2, 2, '2018-05-24 19:36:09'),
(2, 5, '2018-05-24 19:36:09'),
(2, 6, '2018-05-24 19:36:40'),
(2, 7, '2018-05-24 19:37:39'),
(3, 8, '2018-05-24 19:38:24'),
(3, 9, '2018-05-24 19:39:17'),
(3, 10, '2018-05-24 19:39:35');

-- --------------------------------------------------------

--
-- Table structure for table `role`
--

CREATE TABLE `role` (
  `id` int(1) NOT NULL,
  `name` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `role`
--

INSERT INTO `role` (`id`, `name`) VALUES
(1, 'Admin'),
(2, 'Student');

-- --------------------------------------------------------

--
-- Table structure for table `school`
--

CREATE TABLE `school` (
  `id` int(5) NOT NULL,
  `name` varchar(150) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `school`
--

INSERT INTO `school` (`id`, `name`, `address`) VALUES
(1, 'Brisbane Grammar School', '24 Gregory Terrace, Spring Hill QLD 4000'),
(2, 'Brisbane State High School', 'Cordelia St & Glenelg St, South Brisbane QLD 4101');

-- --------------------------------------------------------

--
-- Table structure for table `status`
--

CREATE TABLE `status` (
  `id` int(2) NOT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `status`
--

INSERT INTO `status` (`id`, `name`) VALUES
(3, 'deleted'),
(2, 'hidden'),
(1, 'visible');

-- --------------------------------------------------------

--
-- Table structure for table `topic`
--

CREATE TABLE `topic` (
  `id` int(3) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `content_title` varchar(50) DEFAULT NULL,
  `content_image` varchar(255) DEFAULT NULL,
  `content_text` text,
  `status_id` int(2) DEFAULT NULL,
  `category_id` int(3) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `topic`
--

INSERT INTO `topic` (`id`, `name`, `content_title`, `content_image`, `content_text`, `status_id`, `category_id`) VALUES
(1, 'Awareness of the environment', '', '', 'o What is ahead\no What is on either side of the vehicle\no What is behind\no What is the likely reaction of persons, animals or mechanical devices\njust ahead\no Activities within the vehicle\no Peer pressure to do something illegal and/or dangerous both from\nwithin or external to the vehicle\n', 1, 22);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `name` varchar(15) DEFAULT NULL,
  `middle_name` varchar(15) DEFAULT NULL,
  `surname` varchar(30) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobile_number` varchar(15) DEFAULT NULL,
  `address` varchar(150) DEFAULT NULL,
  `birthday` datetime DEFAULT NULL,
  `visible` tinyint(1) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `token` varchar(150) DEFAULT NULL,
  `token_timestamp` datetime DEFAULT NULL,
  `school_id` int(5) DEFAULT NULL,
  `total_score` int(10) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `role_id`, `name`, `middle_name`, `surname`, `email`, `mobile_number`, `address`, `birthday`, `visible`, `password`, `token`, `token_timestamp`, `school_id`, `total_score`) VALUES
(5, 1, 'Jake', 'willie', 'Warren', 'thundertau@hotmail.com', '0466 887 964', '2/73 malabar st', '1990-11-04 00:00:00', 1, '$2y$10$pP/ETDLxcBhJntnfnizDKuuX1.ttDUWX/RAWvEr5ikgfwdjCn9jzS', NULL, NULL, 1, 0),
(6, 2, 'adf', 'aswefg', 'rew', '01010@mail.com', '0404040404', '04 asr st', '1999-01-01 00:00:00', 1, '$2y$10$LsDCX/g8uuDQZAqi3in7qeYxNT1BwL4m9lyiVApTsDGhbPKpcJYfW', NULL, NULL, 1, 0),
(7, 2, 'user ', 'yo', 'Lo ', '123@mail.com', '01231564', 'Call 18', '2010-10-31 00:00:00', 1, '$2y$10$ljYdS342VwXCx4iwnrrXBOKe2aL7Df96OiJMjz8mFYcj2.1XAQTd.', NULL, NULL, 1, 58);

-- --------------------------------------------------------

--
-- Table structure for table `user_category`
--

CREATE TABLE `user_category` (
  `user_id` int(11) NOT NULL,
  `category_id` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `FK_category_status` (`status_id`);

--
-- Indexes for table `login_attempt`
--
ALTER TABLE `login_attempt`
  ADD PRIMARY KEY (`user_id`,`time`);

--
-- Indexes for table `option`
--
ALTER TABLE `option`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `question`
--
ALTER TABLE `question`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `FK_question_topic` (`topic_id`);

--
-- Indexes for table `question_option`
--
ALTER TABLE `question_option`
  ADD PRIMARY KEY (`question_id`,`option_id`),
  ADD KEY `FK_questionOption_option` (`option_id`);

--
-- Indexes for table `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `school`
--
ALTER TABLE `school`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`);

--
-- Indexes for table `topic`
--
ALTER TABLE `topic`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `name` (`name`),
  ADD KEY `FK_topic_category` (`category_id`),
  ADD KEY `FK_topic_status` (`status_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_user_rol` (`role_id`),
  ADD KEY `FK_user_school` (`school_id`);

--
-- Indexes for table `user_category`
--
ALTER TABLE `user_category`
  ADD PRIMARY KEY (`user_id`,`category_id`),
  ADD KEY `FK_userCategory_category` (`category_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `option`
--
ALTER TABLE `option`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `question`
--
ALTER TABLE `question`
  MODIFY `id` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `role`
--
ALTER TABLE `role`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `school`
--
ALTER TABLE `school`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `status`
--
ALTER TABLE `status`
  MODIFY `id` int(2) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `topic`
--
ALTER TABLE `topic`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `category`
--
ALTER TABLE `category`
  ADD CONSTRAINT `FK_category_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`);

--
-- Constraints for table `login_attempt`
--
ALTER TABLE `login_attempt`
  ADD CONSTRAINT `FK_loginAttempt_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Constraints for table `question`
--
ALTER TABLE `question`
  ADD CONSTRAINT `FK_question_topic` FOREIGN KEY (`topic_id`) REFERENCES `topic` (`id`);

--
-- Constraints for table `question_option`
--
ALTER TABLE `question_option`
  ADD CONSTRAINT `FK_questionOption_option` FOREIGN KEY (`option_id`) REFERENCES `option` (`id`),
  ADD CONSTRAINT `FK_questionOption_question` FOREIGN KEY (`question_id`) REFERENCES `question` (`id`);

--
-- Constraints for table `topic`
--
ALTER TABLE `topic`
  ADD CONSTRAINT `FK_topic_category` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `FK_topic_status` FOREIGN KEY (`status_id`) REFERENCES `status` (`id`);

--
-- Constraints for table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `FK_user_rol` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`),
  ADD CONSTRAINT `FK_user_school` FOREIGN KEY (`school_id`) REFERENCES `school` (`id`);

--
-- Constraints for table `user_category`
--
ALTER TABLE `user_category`
  ADD CONSTRAINT `FK_userCategory_category` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `FK_userCategory_user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
