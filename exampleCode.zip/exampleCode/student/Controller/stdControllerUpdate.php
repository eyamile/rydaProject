<?php
  include_once('student/Model/stdModelUpdate.php');
  include_once('login/Model/ModelLogin.php');


  /**
   *
   */
  class stdControllerUpdate
  {
  public $st_modelUpdate;
  public $modelLogin;



    function __construct()
    {

      $this->modelLogin = new ModelLogin();
      $this->st_modelUpdate = new stdModelUpdate();

    }


    function updateProfile()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

        if(isset($_POST['name'], $_POST['middleName'], $_POST['surname'], $_POST['phoneNumber'], $_POST['address'], $_POST['email'] ))
          $name = $_POST['name'];
          $middleName = $_POST['middleName'];
          $surname = $_POST['surname'];
          $phoneNumber = $_POST['phoneNumber'];
          $address = $_POST['address'];
          $email = $_POST['email'];
          $this->st_modelUpdate->editProfile($email, $name, $middleName, $surname, $phoneNumber, $address);

        }
      else {
        header('Location:log');
      }
    }








    function updateScore()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && ($_SESSION['rol'] == 1 || $_SESSION['rol'] == 2 )){

          $data = json_decode(file_get_contents('php://input'),true);
          $user = $data['user'];
          $score = $data['score'];
          $this->st_modelUpdate->editScore($user, $score);

      }
      else {
        header('Location:log');
      }
    }


  }


 ?>
