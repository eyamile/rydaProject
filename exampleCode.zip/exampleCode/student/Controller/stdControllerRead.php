<?php
  include_once('student/Model/stdModelRead.php');
  include_once('login/Model/ModelLogin.php');

  /**
   *
   */
  class stdControllerRead
  {
  public $stdModelRead;
  public $modelLogin;



    function __construct()
    {
      $this->stdModelRead = new stdModelRead();
      $this->modelLogin = new ModelLogin();

    }


    function readCategories()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() &&  $_SESSION['rol'] == 2 ){
            $categories =  $this->stdModelRead->getCategories();
            require'student/View/categories.php';
            return $categories;
      }
      else {
        header('Location:log');
      }
    }



    function readScore()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() &&  $_SESSION['rol'] == 2 ){
        if(isset($_POST['email'])){
          $email = $_POST['email'];
          $score =  $this->stdModelRead->getScore($email);
          require'student/View/score.php';
          return $score;
        }

      }
      else {
        header('Location:log');
      }
   }




    function readTopics()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && ($_SESSION['rol'] == 1 || $_SESSION['rol'] == 2)  ){
            if(isset($_POST['cat_id'])){
              $cat_id = $_POST['cat_id'];
              $topics =  $this->stdModelRead->getTopics($cat_id);
              require'student/View/topics.php';
              return array($topics, $cat_id);
            }

      }
      else {
        header('Location:log');
      }


    }




    function readTopic()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && ($_SESSION['rol'] == 1 || $_SESSION['rol'] == 2)  ){

            if(isset($_POST['topic_id'])){
              $topic_id = $_POST['topic_id'];
              $topic =  $this->stdModelRead->getTopic($topic_id);
              require'student/View/topicInformation.php';
              return array($topic,$topic_id);
            }

      }
      else {
        header('Location:log');
      }
    }



    function readQuestion()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && ($_SESSION['rol'] == 1 || $_SESSION['rol'] == 2)  ){
        $topic_id = $_GET['id'];
        $questions =  $this->stdModelRead->getQuestions($topic_id);
              require'student/View/ansQuestion.php';
        return $questions;

      }
      else {
        header('Location:log');
      }
    }




    function optionsAvailable()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && ($_SESSION['rol'] == 1 || $_SESSION['rol'] == 2)  ){
              $data = json_decode(file_get_contents('php://input'),true);
              $question_id = $data['question_id'];
              $allOptions = $this->stdModelRead->getAllOptions($question_id);
              echo json_encode($allOptions);

      }
      else {
        header('Location:log');
      }
    }








  }


 ?>
