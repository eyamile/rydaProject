<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link href="bootstrap/open-iconic-master/font/css/open-iconic-bootstrap.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script src="https://code.jquery.com/jquery-3.3.1.js"  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
    crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>

    <title>Home</title>
  </head>
  <body class="text-center">

  <!-- NAV BAR -->
  <nav class="navbar fixed-top navbar-dark bg-dark">
    <div class="navbar-brand ">
      <!--<a  href="home"><span class="oi oi-arrow-circle-left btn-dark mr-1"></span></a>-->
      <a  href="home"><span class="oi oi-home  btn-dark"></span></a>
    </div>
     <a class="navbar-brand btn-dark " href="#">Home</a>
     <div class="navbar" id="navbarsExampleDefault">

         <li class="nav-item  form-inline my-2 my-lg-0">
         <a class="nav-item nav-link  mr-md-5 btn-dark  " href="logout" >
           Logout
         </a>

       </li>
     </div>
   </nav> <!-- end navbar-->

   <input type="hidden" id="email" value="<?php echo $_SESSION['Email'] ?>">

    <div  class="container">
      <div class="row  mt-5">

        <?php
            foreach ($categories as $category) {
              echo "<div class=\"col-sm-3 \">
                <a href=\"#\" data-id=\"".$category['id']."\" class=\"category\">
                  <div class=\"card border-warning mt-5 selection\">
                    <div class=\"card-header\">
                      <span>".$category['name']."</span>
                    </div>
                    <div class=\"card-body\">
                      <img src=\"images/logo.png\">
                    </div>
                  </div>
                </a>

              </div>";
            }

         ?>


      </div>

    </div>

        <script type="text/javascript" src="student/Scripts/stdCategories.js"> </script>

  </body>
</html>
