<?php
  /**
   *
   */
  class stdModelRead
  {
    private $mysqli;

    function __construct()
    {
      include_once ('includes/psl-config.php');

      $this->mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);

      if ($this->mysqli->connect_error)
        die('Connect Error: ' . $this->mysqli->connect_error);
    }


//ccall the model to call all the categories available for students.
    public function getCategories()
    {
      $query = 'CALL getCategories()';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->execute();
        $stmt->bind_result($id,$name, $image);
        $categories = array();

        while( $stmt->fetch() )
          $categories[] = array('id'=>$id, 'name'=>$name, 'image'=>$image);

        $stmt->close();
        return $categories;
      }
    }



//topics available into the category selected
    public function getTopics($cat_id)
    {
      $query = 'CALL getTopics(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i',$cat_id);
        $stmt->execute();
        $stmt->bind_result($id,$name, $image);
        $topics = array();

        while( $stmt->fetch() )
          $topics[] = array('id'=>$id, 'name'=>$name, 'image'=>$image);

        $stmt->close();
        return $topics;
      }
    }



//get information about an specific topic
    public function getTopic($topic_id)
    {
      $query = 'CALL getTopic(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i', $topic_id);
        $stmt->execute();
        $stmt->bind_result($name, $title, $image, $text);
        if( $stmt->fetch() )
          $topic = array('name'=>$name, 'title'=>$title, 'image'=>$image, 'text'=>$text );

        $stmt->close();
        return $topic;
      }
    }





//get questions that are into an specific topic

    public function getQuestions($topic_id)
    {
      $query = 'CALL getQuestions(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i',$topic_id);
        $stmt->execute();
        $stmt->bind_result($id, $name);
        $questions = array();

        while( $stmt->fetch() )
          $questions[] = array('id'=>$id, 'name'=>$name);

        $stmt->close();
        return $questions;
      }
    }



//get the options details according to the question selected
    public function getAllOptions($question_id)
    {
      $query = 'CALL getDetailedOptions(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i',$question_id);
        $stmt->execute();
        $stmt->bind_result($id, $name, $score, $feedback);
        $allOptions = array();

        while( $stmt->fetch() )
          $allOptions[] = array('id'=>$id, 'name'=>$name, 'score'=>$score, 'feedback'=>$feedback);

        $stmt->close();
        return $allOptions;
      }
    }



//get total score
    public function getScore( $email )
    {
      $query = 'CALL getScore(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('s',$email);
        $stmt->execute();
        $stmt->bind_result($score);


        if( $stmt->fetch() )
          $score = $score;

        $stmt->close();
        return $score;
      }
    }












  }


 ?>
