<?php
  /**
   *
   */
  class stdModelUpdate
  {
    private $mysqli;

    function __construct()
    {
      include_once ('includes/psl-config.php');

      $this->mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);

      if ($this->mysqli->connect_error)
        die('Connect Error: ' . $this->mysqli->connect_error);
    }


  /*public function editProfile( $email, $name, $middleName, $surname, $phone, $address )
  {

      $query = 'CALL updateProfile(?, ?, ?, ?, ?, ?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('ssssss', $email, $name, $middleName, $surname, $phone, $address);
        $stmt->execute();
        $stmt->close();
        header('location:home');
      }
    }
  }*/


  public function editScore( $user, $score )
  {

      $query = 'CALL updateScore(?, ?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('si', $user, $score);
        $stmt->execute();
        $stmt->close();
      }
    }
  }


 ?>
