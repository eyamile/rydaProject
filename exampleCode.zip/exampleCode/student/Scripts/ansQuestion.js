$(document).ready(function()
{
  var questions = JSON.parse($('#questions').val());
  var counter = 0;
  var question_id = 0;
  showQuestion(counter);
  console.log('questionlenght: '+questions);
  console.log(questions);

  var info;

   $('#nextQuestion').click(function()
   {

     console.log('counter'+counter);
       counter ++;
     showQuestion(counter);
     $('#nextQuestion').attr("disabled", "disabled");




   });


   $(document).on('change', '.selection', function() {
        $('#ansQuestion').removeAttr("disabled");
         $('#nextQuestion').attr("disabled", "disabled");
   });


   $('#ansQuestion').click(function(){
     var option = $("input[name='selected']:checked").attr("data-counter");
     var feedback = info[option].feedback;
     var score = info[option].score;
     var user = $('#email').val();
     var data = {'user':user, 'score':score};

     $.ajax
     ({
       url:'addScore',
       contentType: 'application/x-www-form-urlencoded',
       type:'post',
       data: JSON.stringify(data)
     })
     .done(function(data)
     {
       try{
         $('#feedback').html(`<span>Feedback: ${feedback}</span>`);
           $('#ansQuestion').attr("disabled", "disabled");
           $('#nextQuestion').removeAttr("disabled");
           $('#nextQuestion').show();
       }catch (e) {
         console.log('error: '+err);
       }
     })



   });









  function showQuestion(counter){

    if(counter < questions.length)
    {

      $('#questionName').text(questions[counter].name);
      question_id = questions[counter].id;
      showOptions(questions[counter].id);


    }
    else {
      location.href = 'quiz';
    }
  }



  function showOptions(q_id){
    var data = {'question_id':q_id};
    var optionCounter = 0;

    console.log(data);
    $('.questionOptions').empty();
    $('#feedback').empty();
    $.ajax
    ({
      url:'o_available',
      contentType: 'application/x-www-form-urlencoded',
      type:'post',
      data: JSON.stringify(data)
    })
    .done(function(data)
    {
      try{
        info = $.parseJSON(data);
        var html = '';

        $.each(info,function(k,inf)
        {
          html+=`<div class="custom-control custom-radio col-sm-12">
                  <span id="optCounter">${optionCounter+1}. <span>
                  <input type="radio" id="${inf.id}" name="selected" data-counter="${optionCounter}" class="custom-control-input selection">
                  <label class="custom-control-label" for="${inf.id}">${inf.name}</label>
                </div>`;
                optionCounter++;
        });
        $('.questionOptions').append(html);

      }catch (e) {
        console.log('error: '+e);
      }
    })

  }
});
