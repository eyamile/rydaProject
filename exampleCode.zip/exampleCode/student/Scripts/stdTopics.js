$('.topic').click(function(){
  var topic_id = $(this).attr("data-id");
  viewTopicInfo(topic_id);
});



function viewTopicInfo(topic_id){
  var data = {'cat_id':topic_id};

  var form = document.createElement("form");
  var id = document.createElement("input");

  form.method = "POST";
  form.action = "topicInformation";

  id.value = topic_id;
  id.name = "topic_id";
  id.type = "hidden";

  form.appendChild(id);

  document.body.appendChild(form);
  form.submit();
}
