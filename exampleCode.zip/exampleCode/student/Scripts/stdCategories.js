$('.category').click(function(){
  var cat_id = $(this).attr("data-id");
  viewTopics(cat_id);
});



function viewTopics(cat_id){
  var data = {'cat_id':cat_id};

  var form = document.createElement("form");
  var id = document.createElement("input");

  form.method = "POST";
  form.action = "selectTopic";

  id.value = cat_id;
  id.name = "cat_id";
  id.type = "hidden";

  form.appendChild(id);

  document.body.appendChild(form);
  form.submit();
}
