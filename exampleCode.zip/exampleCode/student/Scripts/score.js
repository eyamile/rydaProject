$('#score').click(function(){
  var email = $('#email').val();
  checkScore(email);
});




function checkScore (email){

    var form = document.createElement("form");
    var id = document.createElement("input");

    form.method = "POST";
    form.action = "score";

    id.value = email;
    id.name = "email";
    id.type = "hidden";

    form.appendChild(id);

    document.body.appendChild(form);
    form.submit();


}
