<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">

    <script type="text/JavaScript" src="scripts/Login/sha512.js"></script>
    <script type="text/JavaScript" src="scripts/Login/forms.js"></script>



    <title>Registration</title>
  </head>
  <body class="text-center">
      <div class="container">

          <form class="mt-3" action="registration" method="POST" id="registrationFrom">
            <div class=" col-md-4 offset-md-4">
              <br>
              <img class="mt-3" src="images/logo.png" alt="" width="144" height="72">
              <h1 class="h3 mt-3 font-weight-normal ">Registration</h1>

              <div class="form-group">
                <input type="text" id="name" name="name" class="form-control" placeholder="Name" ="" autofocus="">
              </div>


              <div class="form-group">
                <input type="text" id="middleName" name="middleName" class="form-control" placeholder="Middle Name" autofocus="">
              </div>

              <div class="form-group">
                <input type="text" id="surname" name="surname" class="form-control" placeholder="Surname" ="" autofocus="">
              </div>

              <div class="form-group">
                <input placeholder="Birthday" id="birthday" name="birthday" class="form-control" type="text" onfocus="(this.type='date')"  ="">

              </div>

              <div class="form-group">
                <input type="tel" id="phone" name="phone" class="form-control" placeholder="Phone Number"  autofocus="">
              </div>

              <div class="form-group">
                <input type="text" id="address" name="address" class="form-control" placeholder="Address"  autofocus="">
              </div>

              <div class="form-group">
                <label for="inputEmail" class="sr-only">Email address</label>
                <input type="email" id="email" name="email" class="form-control" placeholder="Email address" ="" autofocus="">
              </div>

              <select class="form-control no-border mt-2 mb-4" id="schoolList" name="schoolList">
                <option >School</option>
                <?php
                foreach ($schools as $school):
                  echo "<option  value=\"".$school['id']."\">".$school['name']."</option>";
                endforeach;

                 ?>
              </select>


              <div class="form-group">
                <input type="password" id="password" name="password" class="form-control" placeholder="Password" >
              </div>

              <div class="form-group">
                <input type="password" id="confPassword" name="confPassword" class="form-control" placeholder="Confirm Password" ="">
              </div>

              <input class="btn btn-lg btn-warning btn-block mt-4" type="submit" onclick="return regformhash(this.form,
                                                                                                            this.form.name,
                                                                                                            this.form.middleName,
                                                                                                            this.form.surname,
                                                                                                            this.form.birthday,
                                                                                                            this.form.phone,
                                                                                                            this.form.address,
                                                                                                            this.form.email,
                                                                                                            this.form.schoolList,
                                                                                                            this.form.password,
                                                                                                            this.form.password);"

                <p class="mt-5 mb-3 text-muted">© 2017-2018</p>
            </div>
          </form>
      </div>


  </body>
</html>
