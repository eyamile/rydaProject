<?php
  /**
   *
   */
  class ModelLogin
  {
    private $mysli;

    function __construct()
    {
      include_once ('includes/psl-config.php');

      $this->mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);

      if ($this->mysqli->connect_error)
        die('Connect Error: ' . $this->mysqli->connect_error);
    }




        public function userRegistration()
        {

          $error_msg = "";

          if (isset($_POST['name'], $_POST['middleName'], $_POST['surname'], $_POST['birthday'], $_POST['phone'], $_POST['address'], $_POST['email'], $_POST['schoolList'], $_POST['p']))
          {

              // Sanitize and validate the data passed in

              $name = filter_input(INPUT_POST, 'name', FILTER_SANITIZE_STRING);
              $middleName = filter_input(INPUT_POST, 'middleName', FILTER_SANITIZE_STRING);
              $surname = filter_input(INPUT_POST, 'surname', FILTER_SANITIZE_STRING);
              $birthday = filter_input(INPUT_POST, 'birthday', FILTER_SANITIZE_STRING);
              $phone = filter_input(INPUT_POST, 'phone', FILTER_SANITIZE_STRING);
              $address = filter_input(INPUT_POST, 'address', FILTER_SANITIZE_STRING);
              $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
              $email = filter_var($email, FILTER_VALIDATE_EMAIL);
              $schoolList = $_POST['schoolList'];

              if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                  // Not a valid email
                  $error_msg = 'The email address you entered is not valid';
                  header("Location: registration?error=he email address you entered is not valid.");
              }

              $password = filter_input(INPUT_POST, 'p', FILTER_SANITIZE_STRING);
              if (strlen($password) != 128) {
                  // The hashed pwd should be 128 characters long.
                  // If it's not, something really odd has happened
                  $error_msg = 'Invalid password configuration.';
                  header("Location: registration?error=Invalid password configuration.");
              }

              // Username validity and password validity have been checked client side.
              // This should should be adequate as nobody gains any advantage from
              // breaking these rules.

              $prep_stmt = "SELECT id
                            FROM user
                            WHERE email = ?
                            LIMIT 1";

              $stmt = $this->mysqli->prepare($prep_stmt);

             // check existing email
              if ($stmt)
              {
                  $stmt->bind_param('s', $email);
                  $stmt->execute();
                  $stmt->store_result();

                  if ($stmt->num_rows == 1) {
                      // A user with this email address already exists
                      $error_msg .= '<p class="error">A user with this email address already exists.</p>';
                                  $stmt->close();
                  }
              } else
              {
                  $error_msg .= '<p class="error">Database error Line 39</p>';
                  //$stmt->close();
              }


                  // to do We'll also have to account for the situation where the user doesn't have
                  // rights to do registration, by checking what type of user is attempting to
                  // perform the operation.

                  if (empty($error_msg))
                   {

                      // Create hashed password using the password_hash function.
                      // This function salts it with a random salt and can be verified with
                      // the password_verify function.
                      $password = password_hash($password, PASSWORD_BCRYPT);

                      $query = 'CALL createStudent(?, ?, ?, ?, ?, ?, ?, ?, ?)';

                      if ($insert_stmt = $this->mysqli->prepare($query))
                      {
                          $insert_stmt->bind_param('ssssssssi', $name, $middleName, $surname, $email, $phone, $address, $birthday, $password, $schoolList);
                          // Execute the prepared query.
                          if (! $insert_stmt->execute()) {
                            header("Location: registration?error=registration failure");
                              //header('Location: ../error.php?err=Registration failure: INSERT');
                          }
                      }
                      header('Location: log?error=You user has been created, now you can access.');
                  }
                }
           }




           public function startSession()
           {
             $session_name = 'sec_session_id';   // Set a custom session name
             session_name($session_name);
             $secure = SECURE;
             // This stops JavaScript being able to access the session id.
             $httponly = true;
             // Forces sessions to only use cookies.
             ini_set('session.use_only_cookies', '1');


               if (('session.use_only_cookies') === FALSE) {

                 header("Location: log?error=problem starting session");
                 exit();
             }

             // Gets current cookies params.
             $cookieParams = session_get_cookie_params();
             session_set_cookie_params($cookieParams["lifetime"], $cookieParams["path"], $cookieParams["domain"], $secure, $httponly);
             // Sets the session name to the one set above.
             session_name($session_name);
             session_start();            // Start the PHP session
             session_regenerate_id();    // regenerated the session, delete the old one.
           }



           public function findUser()
           {
             if (isset($_SESSION['user_id'], $_SESSION['Name'], $_SESSION['login_string']))
             {

               $user_id = $_SESSION['user_id'];
               $login_string = $_SESSION['login_string'];
               $username = $_SESSION['Name'];

               // Get the user-agent string of the user.
               $user_browser = $_SERVER['HTTP_USER_AGENT'];

             /*  $query = "SELECT usrPassword
                         FROM user
                         WHERE usrId = ? LIMIT 1";*/
                 $query = 'CALL getPassword(?)';

               if ($stmt = $this->mysqli->prepare($query))
               {
                   // Bind "$user_id" to parameter.
                   $stmt->bind_param('i', $user_id);
                   $stmt->execute();   // Execute the prepared query.
                   $stmt->store_result();

                   if ($stmt->num_rows == 1)
                   {
                       // If the user exists get variables from result.
                       $stmt->bind_result($password);
                       $stmt->fetch();
                       $login_check = hash('sha512', $password . $user_browser);

                       if (hash_equals($login_check, $login_string) ){
                           // Logged In!!!!
                           return true;
                       } else {
                           // Not logged in
                           return false;
                       }
                   } else {
                       // Not logged in
                       return false;
                     }
                 } else {
                     // Not logged in
                     return false;
                 }
             } else {
                 // Not logged in
                 return false;
             }
           }



           public function processLogin()
           {

             if (isset($_POST['email'], $_POST['p']))
             {

              $this->startSession();
               $email = $_POST['email'];
               $password = $_POST['p']; // The hashed password.
               if ($this->login($email, $password, $mysqli) == true)
               {
                   header('Location: home');

               } else {
                   // Login failed
                   header('Location: error');
               }
             }
           }



           public function login($email, $password, $mysqli)
           {
              // $query = 'CALL getUser(?)';

               $query = "SELECT id, name, surname,  password, role_id
                     		FROM user
                     		WHERE email = ?
                        LIMIT 1";

               if ($stmt = $this->mysqli->prepare($query))
               {
                   $stmt->bind_param('s', $email);  // Bind "$email" to parameter.
                   $stmt->execute();    // Execute the prepared query.
                   $stmt->store_result();

                   // get variables from result.
                   $stmt->bind_result($user_id, $username, $surname,  $db_password, $rolId);
                   $stmt->fetch();


                   if ($stmt->num_rows == 1)
                   {
                       // If the user exists we check if the account is locked
                       // from too many login attempts

                       if ($this->checkbrute($user_id, $mysqli) == true)
                       {
                           // Account is locked
                           // Send an email to user saying their account is locked
                           return false;
                       }
                       else
                       {
                           // Check if the password in the database matches
                           // the password the user submitted. We are using
                           // the password_verify function to avoid timing attacks.
                           if (password_verify($password, $db_password))
                           {
                               // Password is correct!
                               // Get the user-agent string of the user.
                               $user_browser = $_SERVER['HTTP_USER_AGENT'];
                               // XSS protection as we might print this value
                               $user_id = preg_replace("/[^0-9]+/", "", $user_id);
                               $_SESSION['user_id'] = $user_id;
                               // XSS protection as we might print this value
                               $username = preg_replace("/[^a-zA-Z0-9_\-]+/",
                                                                    "",
                                                                           $username);

                               $_SESSION['Surname'] = $surname;
                               $_SESSION['Name'] = $username;
                               $_SESSION['Email'] = $email;
                               $_SESSION['login_string'] = hash('sha512',$db_password . $user_browser);
                               // Login successful.
                               $_SESSION['rol'] = $rolId;
                               return true;
                           }
                           else
                           {
                               // Password is not correct
                               // We record this attempt in the database
                               $now = time();
                               $this->mysqli->query("INSERT INTO login_attempt(user_id, time)
                                                      VALUES ('$user_id', '$now')");
                               return false;
                           }
                       }
                   } else
                   {
                       // No user exists.
                       return false;
                   }
               }
             }



             public function checkbrute($usrId, $mysqli)
             {
                   // Get timestamp of current time
                   $now = time();

                   // All login attempts are counted from the past 2 hours.
                   $valid_attempts = $now - (2 * 60 * 60);

                   $query = "SELECT time
                             FROM login_attempt
                             WHERE user_id = ?
                             AND time > '$valid_attempts'";

                   //$query = 'CALL getLoginAttempts (?,?)';

                   if ($stmt = $this->mysqli->prepare($query))
                   {
                       //$stmt->bind_param('ii', $usrId, $valid_attempts);
                       $stmt->bind_param('i', $usrId);

                       // Execute the prepared query.
                       $stmt->execute();
                       $stmt->store_result();

                       // If there have been more than 3 failed logins
                       if ($stmt->num_rows > 3)
                       {

                         return true;

                       }
                        else
                           return false;

                   }
             }




             public function closeSession()
             {

               $this->startSession();

               // Unset all session values
               $_SESSION = array();

               // get session parameters
               $params = session_get_cookie_params();

               // Delete the actual cookie.
               setcookie(session_name(),
                       '', time() - 42000,
                       $params["path"],
                       $params["domain"],
                       $params["secure"],
                       $params["httponly"]);

               // Destroy sessions
               session_destroy();
               header('Location: log');
             }



  }


 ?>
