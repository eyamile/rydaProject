<?php
  /**
   *
   */
  class ModelRead
  {
    private $mysli;

    function __construct()
    {
      include_once ('includes/psl-config.php');

      $this->mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);

      if ($this->mysqli->connect_error)
        die('Connect Error: ' . $this->mysqli->connect_error);
    }



    public function getSchools()
    {
      $query = 'CALL getSchools()';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->execute();
        $stmt->bind_result($id,$name);
        $schools = array();

        while( $stmt->fetch() )
          $schools[] = array('id'=>$id, 'name'=>$name);

        $stmt->close();
        return $schools;
      }
    }













  }


 ?>
