<?php
  include_once('login/Model/ModelRead.php');
  include_once('login/Model/ModelLogin.php');

  /**
   *
   */
  class ControllerRead
  {
  public $modelRead;
  public $modelLogin;



    function __construct()
    {
      $this->modelRead = new ModelRead();
      $this->modelLogin = new ModelLogin();

    }


    function home()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser()){
        if($_SESSION['rol'] == 1)
            require'admin/View/mainPage.php';
        else if($_SESSION['rol'] == 2)
            require'student/View/mainPage.php';
       else {
         header('Location:log');
       }
      }
      else {
        header('Location:log');
      }


    }








  }


 ?>
