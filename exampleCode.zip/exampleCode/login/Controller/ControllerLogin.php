<?php
  include_once('login/Model/ModelLogin.php');

  /**
   *
   */
  class ControllerLogin
  {
    public $modelLogin;
   public $modelRead;



    function __construct()
    {
      $this->modelLogin = new ModelLogin();
      $this->modelRead = new ModelRead();

    }


    function login()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser())
      {
        //if($_SESSION['role'] == 1)
           header('Location: home');
      }
      else {
        if(  $this->modelLogin->processLogin())
        {
          header('Location: home');
         }
          else {
            require 'login/View/login.php';
          }
      }
    }




    function logout()
    {
      $this->modelLogin->closeSession();
    }



    function registrationPage()
    {
      $schools = $this->modelRead->getSchools();
      $this->modelLogin->userRegistration();
      require'login/View/registration.php';

      return $schools;

    }

  /*  public function registration()
    {

      require 'View/registration.php';
    }*/










    /*function adminPage()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser())
      {
        if($_SESSION['rol'] == 1)
          require 'pages/admin.php';
      }
      else
      {
        $this->modelLogin->processLogin();
        require 'pages/login.php';
      }

    }




    public function registrationPage()
    {
      $this->modelLogin->userRegistration();
      require 'pages/registration.php';
    }*/

  }


 ?>
