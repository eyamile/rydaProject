<?php
  /**
   *
   */
  class adminModelUpdate
  {
    private $mysqli;

    function __construct()
    {
      include_once ('includes/psl-config.php');

      $this->mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);

      if ($this->mysqli->connect_error)
        die('Connect Error: ' . $this->mysqli->connect_error);
    }


  public function editProfile( $email, $name, $middleName, $surname, $phone, $address )
  {

      $query = 'CALL updateProfile(?, ?, ?, ?, ?, ?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('ssssss', $email, $name, $middleName, $surname, $phone, $address);
        $stmt->execute();
        $stmt->close();
        header('location:home');
      }
    }




  public function removeCategory( $cat_id )
  {

      $query = 'CALL delCategory(?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('i',  $cat_id);
        $stmt->execute();
        $stmt->close();
        header('location:home');
      }
    }




  public function editCategory( $cat_id , $cat_name)
  {

      $query = 'CALL updateCategory(?, ?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('is', $cat_id, $cat_name);
        $stmt->execute();
        $stmt->close();

      }
    }




  public function editTopic( $topic_id, $name, $title, $image, $content )
  {

      $query = 'CALL updateTopic(?, ?, ?, ?, ?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('issss', $topic_id, $name, $title, $image, $content);
        $stmt->execute();
        $stmt->close();

      }
    }




  public function editQuestion( $question_id, $name, $image )
  {

      $query = 'CALL updateQuestion(?, ?, ?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('iss', $question_id, $name, $image );
        $stmt->execute();
        $stmt->close();

      }
    }




  public function editOption( $opt_id, $name, $score, $feedback )
  {

      $query = 'CALL updateOption(?, ?, ?, ?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('isis', $opt_id, $name, $score, $feedback );
        $stmt->execute();
        $stmt->close();

      }
    }




  public function editStudent( $student_id )
  {

      $query = 'CALL banStudent(?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('i', $student_id );
        $stmt->execute();
        $stmt->close();

      }
    }



    public function removeTopic( $topic_id )
    {

        $query = 'CALL delTopic(?)';

        if( $stmt = $this->mysqli->prepare($query) ){

          $stmt->bind_param('i',  $topic_id);
          $stmt->execute();
          $stmt->close();
        }
      }




    public function removeQuestion( $question_id )
    {

        $query = 'CALL delQuestion(?)';

        if( $stmt = $this->mysqli->prepare($query) ){

          $stmt->bind_param('i',  $question_id);
          $stmt->execute();
          $stmt->close();
        }
      }





    public function removeOption( $opt_id, $question_id )
    {

        $query = 'CALL delOption(?, ?)';

        if( $stmt = $this->mysqli->prepare($query) ){

          $stmt->bind_param('ii',  $opt_id, $question_id);
          $stmt->execute();
          $stmt->close();
        }
      }





















  }


 ?>
