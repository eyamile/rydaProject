<?php
  /**
   *
   */
  class adminModelCreate
  {
    private $mysqli;

    function __construct()
    {
      include_once ('includes/psl-config.php');

      $this->mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);

      if ($this->mysqli->connect_error)
        die('Connect Error: ' . $this->mysqli->connect_error);
    }



    public function addCategory($name, $image)
    {
      $query = 'CALL createCategory(?, ?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('ss', $name, $image);
        $stmt->execute();
        $stmt->close();

      }
    }




    public function addTopic($name, $title, $image, $content, $cat_id)
    {
      $query = 'CALL createTopic(?, ?, ?, ?, ?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('ssssi', $name, $title, $image, $content, $cat_id);
        $stmt->execute();
        $stmt->close();
      }
    }




    public function addQuestion($name, $image, $topic_id)
    {
      $query = 'CALL createQuestion(?, ?, ?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('ssi', $name, $image, $topic_id);
        $stmt->execute();
        $stmt->close();
      }
    }




    public function addOption($name, $score, $feedback, $question_id)
    {
      $query = 'CALL createOption(?, ?, ?, ?)';

      if( $stmt = $this->mysqli->prepare($query) ){

        $stmt->bind_param('sisi', $name, $score, $feedback, $question_id);
        $stmt->execute();
        $stmt->close();
      }
    }



    public function addOptions($opt_Id, $q_Id)
    {
      $options = array();
      $options = json_decode($opt_Id);
      $insert_options = 'CALL addOptions( ?, ? )';
      if( $stm = $this->mysqli->prepare($insert_options)){
        for((int) $i = 0; $i < count($options); $i++){
          $stm->bind_param('ii', $options[$i], $q_Id);
          $stm->execute();
        }
        $stm->close();
      }
      else {
        $stm->close();
      }
    }

















  }


 ?>
