<?php
  /**
   *
   */
  class adminModelRead
  {
    private $mysqli;

    function __construct()
    {
      include_once ('includes/psl-config.php');

      $this->mysqli = new mysqli(HOST, USER, PASSWORD, DATABASE);

      if ($this->mysqli->connect_error)
        die('Connect Error: ' . $this->mysqli->connect_error);
    }



    public function getCategories()
    {
      $query = 'CALL getCategories()';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->execute();
        $stmt->bind_result($id,$name, $image);
        $categories = array();

        while( $stmt->fetch() )
          $categories[] = array('id'=>$id, 'name'=>$name, 'image'=>$image);

        $stmt->close();
        return $categories;
      }
    }




    public function getTopics($cat_id)
    {
      $query = 'CALL getTopics(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i',$cat_id);
        $stmt->execute();
        $stmt->bind_result($id,$name, $image);
        $topics = array();

        while( $stmt->fetch() )
          $topics[] = array('id'=>$id, 'name'=>$name, 'image'=>$image);

        $stmt->close();
        return $topics;
      }
    }




    public function getQuestions($topic_id)
    {
      $query = 'CALL getQuestions(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i',$topic_id);
        $stmt->execute();
        $stmt->bind_result($id, $name);
        $questions = array();

        while( $stmt->fetch() )
          $questions[] = array('id'=>$id, 'name'=>$name);

        $stmt->close();
        return $questions;
      }
    }




    public function getOptionsByID($question_id)
    {
      $query = 'CALL getOptionsByQuestion(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i',$question_id);
        $stmt->execute();
        $stmt->bind_result($id,$name);
        $options = array();

        while( $stmt->fetch() )
          $options[] = array('id'=>$id, 'name'=>$name);

        $stmt->close();
        return $options;
      }
    }




    public function getAllOptions($question_id)
    {
      $query = 'CALL getOptions(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i',$question_id);
        $stmt->execute();
        $stmt->bind_result($id,$name);
        $allOptions = array();

        while( $stmt->fetch() )
          $allOptions[] = array('id'=>$id, 'name'=>$name);

        $stmt->close();
        return $allOptions;
      }
    }




    public function getProfile($email)
    {
      $query = 'CALL getProfile(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('s',$email);
        $stmt->execute();
        $stmt->bind_result($name, $middle_name, $surname, $mobile_number, $address, $birthday);

        if( $stmt->fetch() )
          $profile = array('name'=>$name, 'middle_name'=>$middle_name, 'surname'=>$surname, 'mobile_number'=>$mobile_number, 'address'=>$address, 'birthday'=>$birthday);

        $stmt->close();
        return $profile;
      }
    }




    public function getCategory($cat_id)
    {
      $query = 'CALL getCategory(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i', $cat_id);
        $stmt->execute();
        $stmt->bind_result($name);

        if( $stmt->fetch() )
          $category = array('name'=>$name);

        $stmt->close();
        return $category;
      }
    }




    public function getTopic($topic_id)
    {
      $query = 'CALL getTopic(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i', $topic_id);
        $stmt->execute();
        $stmt->bind_result($name, $title, $image, $text);
        if( $stmt->fetch() )
          $topic = array('name'=>$name, 'title'=>$title, 'image'=>$image, 'text'=>$text );

        $stmt->close();
        return $topic;
      }
    }




    public function getQuestion( $question_id )
    {
      $query = 'CALL getQuestion(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i', $question_id);
        $stmt->execute();
        $stmt->bind_result($name, $image );
        if( $stmt->fetch() )
          $question = array('name'=>$name, 'image'=>$image );

        $stmt->close();
        return $question;
      }
    }




    public function getOption( $opt_id )
    {
      $query = 'CALL getOption(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i', $opt_id);
        $stmt->execute();
        $stmt->bind_result($name, $score, $feedback );
        if( $stmt->fetch() )
          $option = array('name'=>$name, 'score'=>$score, 'feedback'=>$feedback );

        $stmt->close();
        return $option;
      }
    }





    public function getCatId($topic_id)
    {
      $query = 'CALL getCat_id(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i', $topic_id);
        $stmt->execute();
        $stmt->bind_result($cat_id);
        if( $stmt->fetch() )
          $category_id = $cat_id;

        $stmt->close();
        return $category_id;
      }
    }




    public function getTopicId($question_id)
    {
      $query = 'CALL getTopic_id(?)';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->bind_param('i', $question_id);
        $stmt->execute();
        $stmt->bind_result($top_id);
        if( $stmt->fetch() )
          $topic_id = $top_id;

        $stmt->close();
        return $topic_id;
      }
    }





    public function getStudents()
    {
      $query = 'CALL getStudents()';

      if( $stmt = $this->mysqli->prepare($query) ){
        $stmt->execute();
        $stmt->bind_result($id, $name, $surname, $visible);
        $students = array();
        
        while( $stmt->fetch() )
          $students[] = array('id'=>$id, 'name'=>$name, 'surname'=>$surname, 'visible'=>$visible );

        $stmt->close();
        return $students;
      }
    }













  }


 ?>
