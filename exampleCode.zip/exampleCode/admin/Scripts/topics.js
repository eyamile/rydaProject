$('#save').click(function()
{

  saveTopic();
});

$('.question').click(function(){

  var topic_id = $(this).data("id");
  showQuestions(topic_id);

});



$('.delete').click(function(){
  var topic_id = $(this).attr("data-id");
  deleteTopic(topic_id);

});


$(document).ready(function()
{
  var topic_id;

  $('.showTopic').click(function(){
    topic_id = $(this).attr("data-id");
      showTopic(topic_id);
  });

  $('#btnEditTopic').click(function(){
    editTopic(topic_id);
  });
});




function editTopic(topic_id)
{
  var cat_id = $('#cat_id').val();
  var name = $('#t_name').val();
  var title = $('#t_title').val();
  var image = $('#t_image').val();
  var content = $('#t_content').val();
  var data = {'topic_id':topic_id, 'name':name, 'title':title, 'image':image, 'content':content};
  
  $.ajax
  ({
    url:'editTopic',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
        showTopics(cat_id);
    }catch (e) {
      console.log('error: '+err);
    }
  })
}




function showTopic(topic_id)
{
  var data = {'topic_id':topic_id};
  $.ajax
  ({
    url:'getTopic',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      var info = $.parseJSON(data);
      var html = '';

      $('#edict_topic').html(`<div class="form-group row">
       <label for="t_name" class="col-sm-2 col-form-label">Name:</label>
       <div class="col-sm-10">
         <input type="text" class="form-control" id="t_name" name="t_name" value="${info.name}">
       </div>
     </div>

      <div class="form-group row">
       <label for="t_title" class="col-sm-2 col-form-label">Content Title:</label>
       <div class="col-sm-10">
         <input type="text" class="form-control" id="t_title" name="t_title" value="${info.title}">
       </div>
     </div>

     <div class="form-group row">
      <label for="t_image" class="col-sm-2 col-form-label">Content Image: </label>
      <div class="col-sm-10">
        <input type="file" class="form-control" id="t_image" name="t_image" value="${info.image}">
      </div>
    </div>

    <div class="form-group row">
     <label for="t_content" class="col-sm-2 col-form-label">Content Text:</label>
     <div class="col-sm-10">
       <textarea class="col-sm-12 col-form-label" id="t_content" name="t_content" rows="8"  >${info.text}</textarea>
     </div>
   </div>`);




    }catch (e) {
      console.log('error: '+e);
    }
  });
}




function deleteTopic(topic_id){

  var cat_id = $('#cat_id').val();
  var data = {'topic_id':topic_id};


  $.ajax
  ({
    url:'deleteTopic',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      showTopics(cat_id);
    }catch (e) {
      console.log('error: '+err);
    }
  })

}


function showTopics(cat_id)
{

  var form = document.createElement("form");
  var id = document.createElement("input");

  form.method = "POST";
  form.action = "topics";

  id.value = cat_id;
  id.name = "cat_id";
  id.type = "hidden";

  form.appendChild(id);

  document.body.appendChild(form);
  form.submit();

}




function showQuestions(topic_id)
{

  var form = document.createElement("form");
  var id = document.createElement("input");

  form.method = "POST";
  form.action = "questions";

  id.value = topic_id;
  id.name = "topic_id";
  id.type = "hidden";

  form.appendChild(id);

  document.body.appendChild(form);
  form.submit();

}



function saveTopic()
{
  var name = $('#name').val();
  var title = $('#title').val();
  var image = $('#image').val();
  var content = $('#content').val();
  var cat_id = $('#cat_id').val();

  var data = {'name':name, 'title':title, 'image':image, 'content':content, 'cat_id':cat_id};

  $.ajax
  ({
    url:'addTopic',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      showTopics(cat_id);
    }catch (e) {
      console.log('error: '+err);
    }
  })


}
