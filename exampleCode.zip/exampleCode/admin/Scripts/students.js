$('.ban').click(function(){
  var student_id = $(this).attr("data-id");
  banStudent(student_id);
});



function banStudent(student_id)
{
  var data = {'student_id':student_id};

  $.ajax
  ({
    url:'banStudent',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      window.location.href = 'students';
    }catch (e) {
      console.log('error: '+err);
    }
  })
}
