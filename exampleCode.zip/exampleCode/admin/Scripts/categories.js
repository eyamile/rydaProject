

$('#save').click(function()
{
  saveCategory();
});

$('.delete').click(function(){
  var cat_id = $(this).attr("data-code");
  deleteCategory(cat_id);
});


$('.topic').click(function(){
  var cat_id = $(this).attr("data-id");
  showTopics(cat_id);
});




$(document).ready(function(){
  var cat_id;
  $('.showCategory').click(function(){
     cat_id = $(this).attr("data-id");
    showCategory(cat_id);
  });



  $('#btnEditCategory').click(function(){
    editCategory(cat_id);
  });

});




function showCategory(cat_id)
{

  var data = {'cat_id':cat_id};

  $.ajax
  ({
    url:'getCategory',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      var info = $.parseJSON(data);
      var html = '';

      $('#edit_category').html(`<div class="form-group row">
                                       <label for="name" class="col-sm-2 col-form-label">Name:</label>
                                       <div class="col-sm-10">
                                         <input type="text" class="form-control" id="cat_name" name="cat_name" value="${info.name}">
                                       </div>
                                     </div>
                                     <div class="form-group row">
                                      <label for="image" class="col-sm-2 col-form-label">Image</label>
                                      <div class="col-sm-10">
                                        <input type="file" class="form-control" id="image"name="image" placeholder="">
                                      </div>
                                    </div>`);




    }catch (e) {
      console.log('error: '+err);
    }
  })
}






function showTopics(cat_id)
{

  var form = document.createElement("form");
  var id = document.createElement("input");

  form.method = "POST";
  form.action = "topics";

  id.value = cat_id;
  id.name = "cat_id";
  id.type = "hidden";

  form.appendChild(id);

  document.body.appendChild(form);
  form.submit();

}



function saveCategory()
{
  var name = $('#name').val();
  var image = $('#image').val();
  var data = {'name':name, 'image':image};

  $.ajax
  ({
    url:'addCategory',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      window.location.href = 'manageCategories';
    }catch (e) {
      console.log('error: '+err);
    }
  })


}



function deleteCategory(cat_id)
{
  var data = {'cat_id':cat_id};
  $.ajax
  ({
    url:'deleteCategory',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      window.location.href = 'manageCategories';
    }catch (e) {
      console.log('error: '+err);
    }
  })
}




function editCategory(cat_id){
  var cat_name = $('#cat_name').val();
  var data = {'cat_id':cat_id, 'cat_name':cat_name};
  $.ajax
  ({
    url:'editCategory',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
    //  console.log(data);
      window.location.href = 'manageCategories';
    }catch (e) {
      console.log('error: '+err);
    }
  })
}
