$('#save').click(function()
{

  saveQuestion();
});




$('.option').click(function(){

  var question_id = $(this).data("id");
  showOptions(question_id);

});




$('#mngTopics').click(function(){
  showTopics();
});




$(document).ready(function()
{
  var question_id;
  $('.showQuestion').click(function(){
    question_id = $(this).attr("data-id");
    showQuestion(question_id);
  });



  $('#btnEditQuestion').click(function()
  {
    editQuestion(question_id);
  });
});




$('.delete').click(function()
{
  var question_id = $(this).attr("data-id");
  deleteQuestion(question_id);
});




function deleteQuestion(question_id)
{
  var topic_id = $('#topic_id').val();
  var data = {'question_id':question_id};

  $.ajax
  ({
    url:'deleteQuestion',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{

        showQuestions(topic_id);
    }catch (e) {
      console.log('error: '+err);
    }
  })
}
function editQuestion(question_id)
{
  var topic_id = $('#topic_id').val();
  var name = $('#q_name').val();
  var image = $('#q_image').val();
  var data = {'question_id':question_id, 'name':name, 'image':image };

  $.ajax
  ({
    url:'editQuestion',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{

        showQuestions(topic_id);
    }catch (e) {
      console.log('error: '+err);
    }
  })

}




function showQuestion(question_id)
{
  var data = {'question_id':question_id};

  $.ajax
  ({
    url:'getQuestion',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      var info = $.parseJSON(data);

      $('#edit_question').html(`<div class="form-group row">
                                   <label for="q_name" class="col-sm-2 col-form-label">Name:</label>
                                   <div class="col-sm-10">
                                     <input type="text" class="form-control" id="q_name" name="q_name" value="${info.name}">
                                   </div>
                                 </div>


                                 <div class="form-group row">
                                  <label for="q_image" class="col-sm-2 col-form-label">Image: </label>
                                  <div class="col-sm-10">
                                    <input type="file" class="form-control" id="q_image"name="q_image" value="${info.image}">
                                  </div>
                                </div>`);


    }catch (e) {
      console.log('error: '+e);
    }
  })
}




function showTopics(){
  var topic_id = $('#topic_id').val();

  var data = {'topic_id':topic_id};
  $.ajax
  ({
    url:'categoryId',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      var info = $.parseJSON(data);
      goTopics(info);
    }catch (e) {
      console.log('error: '+e);
    }
  })

}



function goTopics(cat_id)
{

  var form = document.createElement("form");
  var id = document.createElement("input");

  form.method = "POST";
  form.action = "topics";

  id.value = cat_id;
  id.name = "cat_id";
  id.type = "hidden";

  form.appendChild(id);

  document.body.appendChild(form);
  form.submit();

}


function showOptions(question_id)
{

  var form = document.createElement("form");
  var id = document.createElement("input");

  form.method = "POST";
  form.action = "options";

  id.value = question_id;
  id.name = "question_id";
  id.type = "hidden";

  form.appendChild(id);

  document.body.appendChild(form);
  form.submit();

}








function showQuestions(topic_id)
{

  var form = document.createElement("form");
  var id = document.createElement("input");

  form.method = "POST";
  form.action = "questions";

  id.value = topic_id;
  id.name = "topic_id";
  id.type = "hidden";

  form.appendChild(id);

  document.body.appendChild(form);
  form.submit();

}



function saveQuestion()
{
  var name = $('#name').val();
  var image = $('#image').val();
  var topic_id = $('#topic_id').val()
  console.log(topic_id);

  var data = {'name':name, 'image':image, 'topic_id':topic_id};


 console.log(data);
  $.ajax
  ({
    url:'addQuestion',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      showQuestions(topic_id);
    }catch (e) {
      console.log('error: '+err);
    }
  })


}
