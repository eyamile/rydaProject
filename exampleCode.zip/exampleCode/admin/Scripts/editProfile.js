$('#viewProfile').click(function()
{
 viewProfile();
});



function viewProfile()
{
  var email = $('#email').val();
   var data = {'email':email};



   $.ajax
   ({
        url:'profile',
        contentType: 'application/x-www-form-urlencoded',
        type:'post',
        data: JSON.stringify(data)
      })
      .done(function(data)
      {
        try{

          var info = $.parseJSON(data);
          var html = '';

          $('#form_edit_profile').html(`<div class=" col-md-12"> <br>

              <div class="form-group row">
               <label for="name" class="col-sm-2 col-form-label">Name:</label>
               <div class="col-sm-10">
                 <input type="text" class="form-control" id="name" name="name" value="${info.name}" >
               </div>
             </div>


             <div class="form-group row">
              <label for="middleName" class="col-sm-2 col-form-label">Middle Name:</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="middleName" name="middleName" value="${info.middle_name}" >
              </div>
            </div>

            <div class="form-group row">
             <label for="surname" class="col-sm-2 col-form-label">Surname:</label>
             <div class="col-sm-10">
               <input type="text" class="form-control" id="surname" name="surname" value="${info.surname}" >
             </div>
           </div>





          <div class="form-group row">
           <label for="phoneNumber" class="col-sm-2 col-form-label">Phone Number:</label>
           <div class="col-sm-10">
             <input type="tel" class="form-control" id="phoneNumber" name="phoneNumber" value="${info.mobile_number}" >
           </div>
          </div>

          <div class="form-group row">
          <label for="address" class="col-sm-2 col-form-label">Address:</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="address" name="address" value="${info.address}" >
          </div>
          </div>

            </div>`);


        }

        catch(err){
          console.log('error: '+err);
        }
      });

}
