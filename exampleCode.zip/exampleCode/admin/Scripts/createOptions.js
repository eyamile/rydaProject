$(document).ready(function(){
  optionsAvailable();
});


$('#save').click(function()
{
  saveOption();
});


$('#saveOptions').click(function(){
  saveOptions();
});


$('.delete').click(function(){
  var opt_id = $(this).attr("data-id");
  deleteOption(opt_id);
});



$('#mngQuestions').click(function(){
  showQuestions();
});




function showQuestions(){
  var question_id = $('#question_id').val();
  var data = {'question_id':question_id};

  $.ajax
  ({
    url:'topicId',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      var info = $.parseJSON(data);
      goQuestions(info);
    }catch (e) {
      console.log('error: '+e);
    }
  })

}




function goQuestions(topic_id)
{
  var form = document.createElement("form");
  var id = document.createElement("input");

  form.method = "POST";
  form.action = "questions";

  id.value = topic_id;
  id.name = "topic_id";
  id.type = "hidden";

  form.appendChild(id);

  document.body.appendChild(form);
  form.submit();

}




$(document).ready(function(){
  var opt_id;

  $('.showOption').click(function(){
    opt_id = $(this).attr("data-id");
    showOption(opt_id);
  });

  $('#btnEditOption').click(function(){
    editOption(opt_id);
  });
});




function editOption(opt_id){
  var question_id = $('#question_id').val();
  var name = $('#o_name').val();
  var score = $('#o_score').val();
  var feedback = $('#o_feedback').val();
  var data = {'opt_id':opt_id, 'name':name, 'score':score, 'feedback':feedback};

  $.ajax
  ({
    url:'editOption',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
        showOptions(question_id);
    }catch (e) {
      console.log('error: '+err);
    }
  })


}




function showOption(opt_id){
  var data = {'opt_id':opt_id};
  $.ajax
  ({
    url:'getOption',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      var info = $.parseJSON(data);

        $('#edit_option').html(`<div class="form-group row">
                                     <label for="o_name" class="col-sm-2 col-form-label">Option:</label>
                                     <div class="col-sm-10">
                                       <input type="text" class="form-control" id="o_name" name="o_name" value="${info.name}">
                                     </div>
                                   </div>


                                   <div class="form-group row">
                                    <label for="o_score" class="col-sm-2 col-form-label">Score: </label>
                                    <div class="col-sm-10">
                                      <input type="number" min="0" class="form-control" id="o_score"name="o_score" value="${info.score}">
                                    </div>
                                  </div>



                                   <div class="form-group row">
                                    <label for="o_feedback" class="col-sm-2 col-form-label">Feedback: </label>
                                    <div class="col-sm-10">
                                      <input type="text" class="form-control" id="o_feedback"name="o_feedback" value="${info.feedback}">
                                    </div>
                                  </div>`);
    }catch (e) {
      console.log('error: '+e);
    }
  })

}




function deleteOption(opt_id)
{
  var question_id = $('#question_id').val();
  var data = {'opt_id':opt_id, 'question_id':question_id};

  $.ajax
  ({
    url:'deleteOption',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{

      showOptions(question_id);

    }catch (e) {
      console.log('error: '+err);
    }
  })
}




function saveOptions()
{
  var question_id = $('#question_id').val()
  var option_id = [];
  $("input:checkbox[name=options]:checked").each(function(){
    option_id.push($(this).val());
  });

  var data = {'question_id':question_id, 'option_id':option_id};

  $.ajax
  ({
    url:'addOptions',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{

      showOptions(question_id);

    }catch (e) {
      console.log('error: '+err);
    }
  })
}



function optionsAvailable()
{

 var question_id = $('#question_id').val()
 var data = {'question_id':question_id};
 $.ajax
 ({
   url:'optAvailable',
   contentType: 'application/x-www-form-urlencoded',
   type:'post',
   data: JSON.stringify(data)
 })
 .done(function(data)
 {

   try {

     var info = $.parseJSON(data);
     var html = '';

     $.each(info,function(k,inf)
     {
       html+=`<input class="checkbox mt-2" type="checkbox" name="options" value="${inf.id}">
               <label class="ml-4">${inf.name}<br></label>`;
     });
     $('#optionsAvailable').append(html);
   } catch (e) {
     console.log('error: '+e);
   }



 })
}



function showOptions(question_id)
{

  var form = document.createElement("form");
  var id = document.createElement("input");

  form.method = "POST";
  form.action = "options";

  id.value = question_id;
  id.name = "question_id";
  id.type = "hidden";

  form.appendChild(id);

  document.body.appendChild(form);
  form.submit();
   optionsAvailable();
}


function saveOption()
{
  var name = $('#name').val();
  var score = $('#score').val();
  var feedback = $('#feedback').val();
  var question_id = $('#question_id').val()

  var data = {'name':name, 'score':score, 'feedback':feedback, 'question_id':question_id};


  $.ajax
  ({
    url:'addOption',
    contentType: 'application/x-www-form-urlencoded',
    type:'post',
    data: JSON.stringify(data)
  })
  .done(function(data)
  {
    try{
      showOptions(question_id);
    }catch (e) {
      console.log('error: '+err);
    }
  })


}
