<?php
  include_once('admin/Model/adminModelUpdate.php');
  include_once('login/Model/ModelLogin.php');


  /**
   *
   */
  class adminControllerUpdate
  {
  public $ad_modelUpdate;
  public $modelLogin;



    function __construct()
    {

      $this->modelLogin = new ModelLogin();
      $this->ad_modelUpdate = new adminModelUpdate();

    }


    function updateProfile()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser()  && ($_SESSION['rol'] == 1 || $_SESSION['rol'] == 2 )){

        if(isset($_POST['name'], $_POST['middleName'], $_POST['surname'], $_POST['phoneNumber'], $_POST['address'], $_POST['email'] ))
          $name = $_POST['name'];
          $middleName = $_POST['middleName'];
          $surname = $_POST['surname'];
          $phoneNumber = $_POST['phoneNumber'];
          $address = $_POST['address'];
          $email = $_POST['email'];
          $this->ad_modelUpdate->editProfile($email, $name, $middleName, $surname, $phoneNumber, $address);

        }
      else {
        header('Location:log');
      }
    }



//change the status of a category
    function delCategory()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);
          $cat_id = $data['cat_id'];
          $this->ad_modelUpdate->removeCategory($cat_id);

      }
      else {
        header('Location:log');
      }
    }




    //change the status of a question

    function delQuestion()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);
          $question_id = $data['question_id'];
          $this->ad_modelUpdate->removeQuestion($question_id);

      }
      else {
        header('Location:log');
      }
    }



    //change the status of an option

    function delOption()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);
          $opt_id = $data['opt_id'];
          $question_id = $data['question_id'];
          $this->ad_modelUpdate->removeOption($opt_id, $question_id);

      }
      else {
        header('Location:log');
      }
    }



    //edit category

    function edtCategory()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);
          $cat_id = $data['cat_id'];
          $cat_name = $data['cat_name'];
          $this->ad_modelUpdate->editCategory($cat_id, $cat_name);

      }
      else {
        header('Location:log');
      }
    }



    //edit an option

    function edtOption()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);
          $opt_id = $data['opt_id'];
          $name = $data['name'];
          $score = $data['score'];
          $feedback = $data['feedback'];
          $this->ad_modelUpdate->editOption($opt_id, $name, $score, $feedback);

      }
      else {
        header('Location:log');
      }
    }



//update student information
    function updateStudent()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);
          $student_id = $data['student_id'];
          $this->ad_modelUpdate->editStudent( $student_id );

      }
      else {
        header('Location:log');
      }
    }



//edit topic
    function edtTopic()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);
          $topic_id = $data['topic_id'];
          $name = $data['name'];
          $title = $data['title'];
          $image = $data['image'];
          $content = $data['content'];
          $this->ad_modelUpdate->editTopic($topic_id, $name, $title, $image, $content);

      }
      else {
        header('Location:log');
      }
    }


//modify question

    function edtQuestion()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);
          $question_id = $data['question_id'];
          $name = $data['name'];
          $image = $data['image'];
          $this->ad_modelUpdate->editQuestion($question_id, $name, $image);

      }
      else {
        header('Location:log');
      }
    }


//hide the topic
    function delTopic()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);
          $topic_id = $data['topic_id'];
          $this->ad_modelUpdate->removeTopic($topic_id);

      }
      else {
        header('Location:log');
      }
    }


























  }


 ?>
