<?php
  include_once('admin/Model/adminModelRead.php');
  include_once('login/Model/ModelLogin.php');

  /**
   *
   */
  class adminControllerRead
  {
  public $modelRead;
  public $modelLogin;



    function __construct()
    {
      $this->modelRead = new adminModelRead();
      $this->modelLogin = new ModelLogin();

    }

//connects to the database to get all the categories
    function mngCategories()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
            $categories =  $this->modelRead->getCategories();
            require'admin/View/manageCategories.php';
            return $categories;
      }
      else {
        header('Location:log');
      }


    }



//connects to the database to get all the topics
    function mngTopics()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
            if(isset($_POST['cat_id'])){
              $cat_id = $_POST['cat_id'];
              $topics =  $this->modelRead->getTopics($cat_id);
              require'admin/View/manageTopics.php';
              return array($topics, $cat_id);
            }

      }
      else {
        header('Location:log');
      }


    }



//connects to the database to get all the questions
    function mngQuestion()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
            if(isset($_POST['topic_id'])){
              $topic_id = $_POST['topic_id'];

              $questions =  $this->modelRead->getQuestions($topic_id);
              require'admin/View/manageQuestions.php';
              return array($questions, $topic_id);
            }
      }
      else {
        header('Location:log');
      }
    }


//connects to the database to get all the options
    function mngOptions()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
            if(isset($_POST['question_id'])){
              $question_id = $_POST['question_id'];
              $options =  $this->modelRead->getOptionsByID($question_id);
              require'admin/View/manageOptions.php';
              return array($options, $question_id);
            }
      }
      else {
        header('Location:log');
      }
    }





//connects to the database to get the category id by topic id
    function readcatId()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
              $data = json_decode(file_get_contents('php://input'),true);
              $topic_id = $data['topic_id'];
              $category_id = $this->modelRead->getCatId($topic_id);
              echo json_encode($category_id);

      }
      else {
        header('Location:log');
      }
    }



//connects to the database to get topic id by  question id
    function readTopicId()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
              $data = json_decode(file_get_contents('php://input'),true);
              $question_id = $data['question_id'];
              $topic_id = $this->modelRead->getTopicId($question_id);
              echo json_encode($topic_id);

      }
      else {
        header('Location:log');
      }
    }




//connects to the database to get all the students
    function readStudents()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
              $students = $this->modelRead->getStudents();
              require'admin/View/banStudents.php';
              return $students;

      }
      else {
        header('Location:log');
      }
    }






//connects to the database to get all the options available for a specific
    function optionsAvailable()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
              $data = json_decode(file_get_contents('php://input'),true);
              $question_id = $data['question_id'];
              $allOptions = $this->modelRead->getAllOptions($question_id);
              echo json_encode($allOptions);

      }
      else {
        header('Location:log');
      }
    }


//connects to the database to get the profile of an user  by email

    function readProfile()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser()  && ($_SESSION['rol'] == 1 || $_SESSION['rol'] == 2 )){
              $data = json_decode(file_get_contents('php://input'),true);
              $email = $data['email'];
              $profile = $this->modelRead->getProfile($email);
              echo json_encode($profile);

      }
      else {
        header('Location:log');
      }
    }



//connects to the database to get category information by id
    function readCategory()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
              $data = json_decode(file_get_contents('php://input'),true);
              $cat_id = $data['cat_id'];
              $category = $this->modelRead->getCategory($cat_id);
              echo json_encode($category);

      }
      else {
        header('Location:log');
      }
    }



//connects to the database to get topic information by id
    function readTopic()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
              $data = json_decode(file_get_contents('php://input'),true);
              $topic_Id = $data['topic_id'];
              $topic = $this->modelRead->getTopic($topic_Id);
              echo json_encode($topic);

      }
      else {
        header('Location:log');
      }
    }



//connects to the database to get question information by id
    function readQuestion()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
              $data = json_decode(file_get_contents('php://input'),true);
              $question_id = $data['question_id'];
              $question = $this->modelRead->getQuestion($question_id);
              echo json_encode($question);

      }
      else {
        header('Location:log');
      }
    }



//connects to the database to get option information by id
    function readOption()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){
              $data = json_decode(file_get_contents('php://input'),true);
              $opt_id = $data['opt_id'];
              $option = $this->modelRead->getOption($opt_id);
              echo json_encode($option);

      }
      else {
        header('Location:log');
      }
    }








  }


 ?>
