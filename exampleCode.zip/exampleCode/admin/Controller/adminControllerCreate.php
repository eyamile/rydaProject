<?php
  include_once('admin/Model/adminModelRead.php');
  include_once('admin/Model/adminModelCreate.php');
  include_once('login/Model/ModelLogin.php');


  /**
   *
   */
  class adminControllerCreate
  {
  public $modelRead;
  public $modelLogin;
  public $ad_modelCreate;



    function __construct()
    {
      $this->modelRead = new adminModelRead();
      $this->modelLogin = new ModelLogin();
      $this->ad_modelCreate = new adminModelCreate();

    }

   // Controller that calls the model to create a category
    function newCategory()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);
          $name = $data['name'];
          $image = $data['image'];
          $this->ad_modelCreate->addCategory($name, $image);

        }
      else {
        header('Location:log');
      }
    }



 //Controller that calls the model to crate a topic
    function newTopic()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);

          $name = $data['name'];
          $title = $data['title'];
          $image = $data['image'];
          $content = $data['content'];
          $cat_id = $data['cat_id'];
          $this->ad_modelCreate->addTopic($name, $title, $image, $content, $cat_id);

        }
      else {
        header('Location:log');
      }
    }



//Controller that calls the model to create a question
    function newQuestion()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);

          $name = $data['name'];
          $image = $data['image'];
          $topic_id = $data['topic_id'];

          $this->ad_modelCreate->addQuestion($name, $image, $topic_id);

        }
      else {
        header('Location:log');
      }
    }



//Controller that calls the model to create a new option
    function newOption()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);

          $name = $data['name'];
          $score = $data['score'];
          $feedback = $data['feedback'];
          $question_id = $data['question_id'];

          $this->ad_modelCreate->addOption($name, $score, $feedback, $question_id);

        }
      else {
        header('Location:log');
      }
    }



//Controller that calls the model to relate new options to a question
    function moreOptions()
    {
      $this->modelLogin->startSession();

      if(  $this->modelLogin->findUser() && $_SESSION['rol'] == 1 ){

          $data = json_decode(file_get_contents('php://input'),true);

          $option_id = json_encode($data['option_id']);

          $question_id = $data['question_id'];

          $this->ad_modelCreate->addOptions($option_id, $question_id);

        }
      else {
        header('Location:log');
      }
    }








  }


 ?>
