<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link href="bootstrap/open-iconic-master/font/css/open-iconic-bootstrap.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <script src="https://code.jquery.com/jquery-3.3.1.js"  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


    <title>Topics</title>
  </head>
  <body class="text-center">

  <!-- NAV BAR -->
  <!-- NAV BAR -->
  <nav class="navbar fixed-top navbar-dark bg-dark">
    <div class="navbar-brand ">
      <a  href="manageCategories"><span class="oi oi-arrow-circle-left btn-dark mr-1"></span></a>
      <a  href="home"><span class="oi oi-home  btn-dark"></span></a>
    </div>
     <a class="navbar-brand btn-dark " href="#">Topics</a>
     <div class="navbar" id="navbarsExampleDefault">

         <li class="nav-item  form-inline my-2 my-lg-0">
         <a class="nav-item nav-link  mr-md-5 btn-dark  " href="logout" >
           Logout
         </a>

       </li>
     </div>
   </nav> <!-- end navbar-->


    <div  class="container">
      <div class="row  mt-5">
        <div class="table-responsive">
          <div class="col-sm-12 mt-3">
            <button type="button" name="addTopic" class=" mb-3 btn btn-warning float-sm-right float-sm-right float-md-right float-lg-right float-xl-right"><span class="oi oi-plus" data-toggle="modal" data-target="#addTopic">Add Topic</span></button>
          </div>

            <h4 class="mb-4 ">Topics</h4>
            <input type="hidden" id="cat_id" value="<?php echo $cat_id ?>">

          <table class="table">
            <thead>
              <tr>
                <th>Topic</th>
                <th>Options</th>
              </tr>
            </thead>
            <tbody>
              <?php
               foreach ($topics as $topic) {
                 echo "<tr>
                   <th>".$topic['name']."</th>
                   <th>
                     <a data-id=\"".$topic['id']."\" href=\"#\" class=\"delete\"><span class=\"oi oi-trash mr-3\"></span></a>
                     <a data-id=\"".$topic['id']."\" href=\"#\" class=\"showTopic\" data-toggle=\"modal\" data-target=\"#editTopic\"  ><span class=\"oi oi-pencil mr-3\" ></span></a>
                     <button data-id=\"".$topic['id']."\" class=\"btn btn-warning question\"><span class=\"oi oi-pencil mr-3\"> Questions</button>
                   </th>
                 </tr>";
               }

              ?>

            </tbody>
          </table>
        </div>

      </div>

    </div>

  <div class="modal fade" id="addTopic" tabindex="-1" role="dialog" aria-labelledby="addTopic" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Create topic</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form >
          <div class="form-group row">
           <label for="name" class="col-sm-2 col-form-label">Name:</label>
           <div class="col-sm-10">
             <input type="text" class="form-control" id="name" name="name" placeholder="Topic name">
           </div>
         </div>

          <div class="form-group row">
           <label for="title" class="col-sm-2 col-form-label">Content Title:</label>
           <div class="col-sm-10">
             <input type="text" class="form-control" id="title" name="title" placeholder="Topic name">
           </div>
         </div>

         <div class="form-group row">
          <label for="image" class="col-sm-2 col-form-label">Content Image: </label>
          <div class="col-sm-10">
            <input type="file" class="form-control" id="image"name="image" placeholder="">
          </div>
        </div>

        <div class="form-group row">
         <label for="content" class="col-sm-2 col-form-label">Content Text:</label>
         <div class="col-sm-10">
           <textarea class="col-sm-12 col-form-label" id="content" name="content" rows="8" ></textarea>
         </div>
       </div>


        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button id="save" type="button" class="btn btn-warning">Save changes</button>
      </div>

    </div>
  </div>
</div>



<div class="modal fade" id="editTopic" tabindex="-1" role="dialog" aria-labelledby="editTopic" aria-hidden="true">
<div class="modal-dialog" role="document">
  <div class="modal-content">
    <div class="modal-header">
      <h5 class="modal-title" id="exampleModalLabel">Edit topic</h5>
      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">&times;</span>
      </button>
    </div>
    <div class="modal-body">
      <form >
        <div id="edict_topic">

        </div>



      </form>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button id="btnEditTopic" type="button" class="btn btn-warning">Save changes</button>
      </div>
    </div>


  </div>
</div>
</div>
  </body>

  <script type="text/javascript" src="admin/Scripts/topics.js"> </script>
</html>
