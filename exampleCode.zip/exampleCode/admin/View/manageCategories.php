<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link href="bootstrap/open-iconic-master/font/css/open-iconic-bootstrap.css" rel="stylesheet">
    <link href="bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">



    <script src="https://code.jquery.com/jquery-3.3.1.js"  integrity="sha256-2Kok7MbOyxpgUVvAk/HJ2jigOSYS2auK4Pfzbm7uH60="
  crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>


    <title>Categories</title>
  </head>
  <body class="text-center">

  <!-- NAV BAR -->
  <!-- NAV BAR -->
  <nav class="navbar fixed-top navbar-dark bg-dark">
    <div class="navbar-brand ">
      <a  href="home"><span class="oi oi-arrow-circle-left btn-dark mr-1"></span></a>
      <a  href="home"><span class="oi oi-home  btn-dark"></span></a>
    </div>
     <a class="navbar-brand btn-dark " href="#">Categories</a>
     <div class="navbar" id="navbarsExampleDefault">

         <li class="nav-item  form-inline my-2 my-lg-0">
         <a class="nav-item nav-link  mr-md-5 btn-dark  " href="logout" >
           Logout
         </a>

       </li>
     </div>
   </nav> <!-- end navbar-->

    <input type="hidden" id="email" value="<?php echo $_SESSION['Email'] ?>">
    <div  class="container">
      <div class="row  mt-5">
        <div class="table-responsive">
          <div class="col-sm-12 mt-3">
            <button type="button" name="addCategory" class=" mb-3 btn btn-warning float-sm-right float-sm-right float-md-right float-lg-right float-xl-right"><span class="oi oi-plus" data-toggle="modal" data-target="#addCategory">Add Category</span></button>
          </div>

            <h4 class="mb-4 ">Categories</h4>

          <table class="table">
            <thead>
              <tr>
                <th>Category</th>
                <th>Options</th>
              </tr>
            </thead>
            <tbody>
              <?php
               foreach ($categories as $category) {
                 echo "<tr>
                   <th>".$category['name']."</th>
                   <th>
                     <a data-code=\"".$category['id']."\" href=\"#\" class=\"delete\"><span class=\"oi oi-trash mr-3 \"></span></a>
                     <a data-id=\"".$category['id']."\"  href=\"#\" class=\"showCategory\" data-toggle=\"modal\" data-target=\"#editCategory\"><span class=\"oi oi-pencil mr-3 \"></span></a>
                     <button data-id=\"".$category['id']."\" class=\"btn btn-warning topic\"><span class=\"oi oi-pencil mr-3\"> Topics</button>
                   </th>
                 </tr>";
               }

              ?>

            </tbody>
          </table>
        </div>

      </div>

    </div>

    <div class="modal fade" id="addCategory" tabindex="-1" role="dialog" aria-labelledby="addCategory" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form >
          <div class="form-group row">
           <label for="name" class="col-sm-2 col-form-label">Name:</label>
           <div class="col-sm-10">
             <input type="text" class="form-control" id="name" name="name" placeholder="Category name">
           </div>
         </div>
         <div class="form-group row">
          <label for="image" class="col-sm-2 col-form-label">Image</label>
          <div class="col-sm-10">
            <input type="file" class="form-control" id="image"name="image" placeholder="">
          </div>
        </div>


        </form>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button id="save" type="button" class="btn btn-warning">Save changes</button>
      </div>

    </div>
  </div>
</div>




<div class="modal fade" id="editCategory" tabindex="-1" role="dialog" aria-labelledby="editCategory" aria-hidden="true">
<div class="modal-dialog" role="document">
<div class="modal-content">
  <div class="modal-header">
    <h5 class="modal-title" id="exampleModalLabel">Edit Category</h5>
    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
      <span aria-hidden="true">&times;</span>
    </button>
  </div>
  <div class="modal-body">
    <form id="form_edit_category" >
      <div id="edit_category">

      </div>

    </form>
    <div class="modal-footer">
      <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      <button id="btnEditCategory" type="button" class="btn btn-warning">Save changes</button>
    </div>
  </div>


</div>
</div>
</div>




  </body>

  <script type="text/javascript" src="admin/Scripts/categories.js"> </script>
</html>
