<?php
/**
 * These are the database login details
 */
    define("HOST", "localhost");     // The host you want to connect to.
    define("USER", "root");    // The database username.
    define("PASSWORD", "");    // The database password.
    define("DATABASE", "ryda");    // The database name.
    define("SECURE", FALSE);    // FOR DEVELOPMENT ONLY!!!!
?>
