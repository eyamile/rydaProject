

function formhash(form, password)
{
    // Create a new element input, this will be our hashed password field.
    var p = document.createElement("input");

    // Add the new element to our form.
    form.appendChild(p);
    p.name = "p";
    p.type = "hidden";
    p.value = hex_sha512(password.value);

    // Make sure the plaintext password doesn't get sent.
    password.value = "";

    // Finally submit the form.
    form.submit();
}



function regformhash(form, name, middleName, surname, birthday, phone, address, email, schoolList, password, confPassword)
{

     // Check each field has a value
    if (name.value == ''         ||
          surname.value == ''    ||
          birthday.value =='' ||
          phone.value == '' ||
          address.value == ''     ||
          email.value == ''   ||
          schoolList.value == '' ||
          password.value == '' ||
          confPassword.value == ''
        ) {

        alert('You must provide all the requested details. Please try again');

        return false;
    }



    // Check that the password is sufficiently long (min 6 chars)
    // The check is duplicated below, but this is included to give more
    // specific guidance to the user

    if (password.value.length < 6) {
        alert('Passwords must be at least 6 characters long.  Please try again');
        form.password.focus();
        return false;
    }

    // At least one number, one lowercase and one uppercase letter
    // At least six characters

    var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
    if (!re.test(password.value)) {
        alert('Passwords must contain at least one number, one lowercase and one uppercase letter.  Please try again');
        return false;
    }

    // Check password and confirmation are the same
    if (password.value != confPassword.value) {
        alert('Your password and confirmation do not match. Please try again');
        form.password.focus();
        return false;
    }


    // Create a new element input, this will be our hashed password field.
    var p = document.createElement("input");

    // Add the new element to our form.
    form.appendChild(p);
    p.name = "p";
    p.type = "hidden";
    p.value = hex_sha512(password.value);

  // Make sure the plaintext password doesn't get sent.
    password.value = "";
    confPassword.value = "";

    // Finally submit the form.
    form.submit();
    return true;
}



/* Erika Y. 06/03/2018
Validate new user added by admin */
function regAdformhash(form, name, surname, phone, email, role, password, conf)
{
     // Check each field has a value
    if (name.value == ''         ||
          surname.value == ''     ||
          phone.value == ''     ||
          email.value == ''     ||
          role.value == ''     ||
          password.value == ''  ||
          conf.value == '') {

        alert('You must provide all the requested details. Please try again');
        return false;
    }

    // Check that the password is sufficiently long (min 6 chars)
    // The check is duplicated below, but this is included to give more
    // specific guidance to the user
    if (password.value.length < 6) {
        alert('Passwords must be at least 6 characters long.  Please try again');
        form.password.focus();
        return false;
    }

    // At least one number, one lowercase and one uppercase letter
    // At least six characters

    var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
    if (!re.test(password.value)) {
        alert('Passwords must contain at least one number, one lowercase and one uppercase letter.  Please try again');
        return false;
    }

    // Check password and confirmation are the same
    if (password.value != conf.value) {
        alert('Your password and confirmation do not match. Please try again');
        form.password.focus();
        return false;
    }

    // Create a new element input, this will be our hashed password field.
    var p = document.createElement("input");

    // Add the new element to our form.
    form.appendChild(p);
    p.name = "p";
    p.type = "hidden";
    p.value = hex_sha512(password.value);

    // Make sure the plaintext password doesn't get sent.
    password.value = "";
    conf.value = "";

    // Finally submit the form.
    form.submit();
    return true;
}




function restPassword(form, newPassword, conf)
{
  if (  newPassword.value == ''  ||
        conf.value == '')
        {

      alert('You must provide all the requested details. Please try again');
      return false;
  }
  // Check that the password is sufficiently long (min 6 chars)
  // The check is duplicated below, but this is included to give more
  // specific guidance to the user
  if (newPassword.value.length < 6) {
      alert('Passwords must be at least 6 characters long.  Please try again');
      form.newPassword.focus();
      return false;
  }

  // At least one number, one lowercase and one uppercase letter
  // At least six characters

  var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
  if (!re.test(newPassword.value)) {
      alert('Passwords must contain at least one number, one lowercase and one uppercase letter.  Please try again');
      return false;
  }

  // Check password and confirmation are the same
  if (newPassword.value != conf.value) {
      alert('Your password and confirmation do not match. Please try again');
      form.newPassword.focus();
      return false;
  }

  // Create a new element input, this will be our hashed password field.
  var np = document.createElement("input");
  //var tk = document.createElement("input");

  // Add the new element to our form.

  form.appendChild(np);
  np.name = "np";
  np.type = "hidden";
  np.value = hex_sha512(newPassword.value);


  /*form.appendChild(tk);
  tk.name="tk";
  tk.type="hidden";
  tk.value = hex_sha512(newPassword.value);*/

  // Make sure the plaintext password doesn't get sent.
  newPassword.value = "";
  conf.value = "";
  alert('lajdflajdf');

  // Finally submit the form.
  //form.submit();
  return true;


}


function chgformhash(form,  email, oldPassword, newPassword, conf)
{
     // Check each field has a value
    if (email.value == ''         ||
          oldPassword.value == ''     ||
          newPassword.value == ''  ||
          conf.value == '') {

        alert('You must provide all the requested details. Please try again');
        return false;
    }

    // Check the username


    // Check that the password is sufficiently long (min 6 chars)
    // The check is duplicated below, but this is included to give more
    // specific guidance to the user
    if (newPassword.value.length < 6) {
        alert('Passwords must be at least 6 characters long.  Please try again');
        form.newPassword.focus();
        return false;
    }

    // At least one number, one lowercase and one uppercase letter
    // At least six characters

    var re = /(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{6,}/;
    if (!re.test(newPassword.value)) {
        alert('Passwords must contain at least one number, one lowercase and one uppercase letter.  Please try again');
        return false;
    }

    // Check password and confirmation are the same
    if (newPassword.value != conf.value) {
        alert('Your password and confirmation do not match. Please try again');
        form.password.focus();
        return false;
    }

    // Create a new element input, this will be our hashed password field.
    var op = document.createElement("input");
    var np = document.createElement("input");

    // Add the new element to our form.
    form.appendChild(op);
    op.name = "op";
    op.type = "hidden";
    op.value = hex_sha512(oldPassword.value);

    form.appendChild(np);
    np.name = "np";
    np.type = "hidden";
    np.value = hex_sha512(newPassword.value);

    // Make sure the plaintext password doesn't get sent.
    newPassword.value = "";
    conf.value = "";
    oldPassword.value = "";

    // Finally submit the form.
    form.submit();
    return true;
}
