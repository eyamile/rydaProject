<?php
  //Login files
  include_once('login/Controller/ControllerLogin.php');
  include_once('login/Controller/ControllerRead.php');

  //Admin Files
 include_once('admin/Controller/adminControllerRead.php');
 include_once('admin/Controller/adminControllerCreate.php');
 include_once('admin/Controller/adminControllerUpdate.php');
  //Student Files
  include_once('student/Controller/stdControllerRead.php');
  include_once('student/Controller/stdControllerUpdate.php');


 //Login files
  $controllerLogin = new ControllerLogin();
  $controllerRead = new ControllerRead();



  //admin
  $adControllerCreate = new adminControllerCreate();
  $adControllerRead = new adminControllerRead();
  $adControllerUpdate = new adminControllerUpdate();

  //students
  $stdControllerRead = new stdControllerRead();
  $stdControllerUpdate = new stdControllerUpdate();

  $URI=$_SERVER['REQUEST_URI'];
  $URLS = explode('?',$URI);
  $URI = $URLS[0];
  $add = '/ryda/';

  switch ($URI)
  {
    case $add.'log':
      $controllerLogin->login();
    break;

    case $add.'registration':
      $controllerLogin->registrationPage();
    break;

    case $add.'categories':
      $controllerRead->categories();
    break;


    case $add.'home':
      $controllerRead->home();
    break;

    case $add.'logout':
      $controllerLogin->logout();
    break;


    //Admin
    case $add.'manageCategories':
      $adControllerRead->mngCategories();
    break;


    case $add.'deleteCategory':
      $adControllerUpdate->delCategory();
    break;


    case $add.'editCategory':
      $adControllerUpdate->edtCategory();
    break;


    case $add.'getCategory':
      $adControllerRead->readCategory();
    break;


    case $add.'topics':
      $adControllerRead->mngTopics();
    break;



    case $add.'deleteTopic':
      $adControllerUpdate->delTopic();
    break;


    case $add.'getTopic':
      $adControllerRead->readTopic();
    break;


    case $add.'categoryId':
      $adControllerRead->readcatId();
    break;


    case $add.'topicId':
      $adControllerRead->readTopicId();
    break;


    case $add.'editTopic':
      $adControllerUpdate->edtTopic();
    break;


    case $add.'questions':
      $adControllerRead->mngQuestion();
    break;


    case $add.'options':
      $adControllerRead->mngOptions();
    break;


    case $add.'optAvailable':
      $adControllerRead->optionsAvailable();
    break;


    case $add.'editOption':
      $adControllerUpdate->edtOption();
    break;


    case $add.'addCategory':
      $adControllerCreate->newCategory();
    break;


    case $add.'addTopic':
      $adControllerCreate->newTopic();
    break;



    case $add.'addQuestion':
      $adControllerCreate->newQuestion();
    break;



    case $add.'editQuestion':
      $adControllerUpdate->edtQuestion();
    break;



    case $add.'getQuestion':
      $adControllerRead->readQuestion();
    break;


    case $add.'deleteQuestion':
      $adControllerUpdate->delQuestion();
    break;


    case $add.'addOption':
      $adControllerCreate->newOption();
    break;


    case $add.'addOptions':
      $adControllerCreate->moreOptions();
    break;


    case $add.'deleteOption':
      $adControllerUpdate->delOption();
    break;




    case $add.'getOption':
      $adControllerRead->readOption();
    break;



    case $add.'profile':
      $adControllerRead->readProfile();
    break;



    case $add.'editProfile':
      $adControllerUpdate->updateProfile();
    break;



    case $add.'students':
      $adControllerRead->readStudents();
    break;



    case $add.'banStudent':
      $adControllerUpdate->updateStudent();
    break;





    //Student

    case $add.'quiz':
      $stdControllerRead->readCategories();
    break;


    case $add.'selectTopic':
      $stdControllerRead->readTopics();
    break;


    case $add.'topicInformation':
      $stdControllerRead->readTopic();
    break;


    case $add.'anwsQuestion':
      $stdControllerRead->readQuestion();
    break;


    case $add.'o_available':
      $stdControllerRead->optionsAvailable();
    break;



    case $add.'addScore':
      $stdControllerUpdate->updateScore();
    break;



    case $add.'score':
      $stdControllerRead->readScore();
    break;



    default:
      $controllerLogin->login();
    break;





  }

 ?>
